package edu.ntnu.idat2001;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class PlayingCardTest {

  @Test
  void getSuit() {
    char actual = new PlayingCard('S', 1).getSuit();
    char expected = 'S';
    assertEquals(expected, actual);
  }

  @Test
  void getFace() {
    int actual = new PlayingCard('S', 1).getFace();
    int expected = 1;
    assertEquals(expected, actual);
  }
}