package edu.ntnu.idat2001;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collection;

import static org.junit.jupiter.api.Assertions.*;

class HandOfCardsTest {

  Collection<PlayingCard> cards;
  HandOfCards handOfCards;
  @BeforeEach
  void setUp() {
    cards = new ArrayList<>();
    cards.add(new PlayingCard('S', 1));
    cards.add(new PlayingCard('S', 2));
    cards.add(new PlayingCard('S', 3));
    cards.add(new PlayingCard('S', 4));
    cards.add(new PlayingCard('S', 5));
    handOfCards = new HandOfCards(cards);
  }
  @Test
  void getHandOfCards() {
    Collection<PlayingCard> actual = handOfCards.getHandOfCards();
    Collection<PlayingCard> expected = cards;
    assertEquals(expected, actual);
  }

  @Test
  void flush() {
    boolean actual = handOfCards.flush();
    boolean expected = true;
    assertEquals(expected, actual);
  }

  @Test
  void getSumOfAllCards() {
    int actual = handOfCards.getSumOfAllCards();
    int expected = 15;
    assertEquals(expected, actual);
  }

  @Test
  void getCardsOfHeart() {
    Collection<PlayingCard> actual = handOfCards.getCardsOfHeart();
    Collection<PlayingCard> expected = new ArrayList<>();
    assertEquals(expected, actual);

  }

  @Test
  void spadeQueenExist() {
    boolean actual = handOfCards.spadeQueenExist();
    boolean expected = false;
    assertEquals(expected, actual);
  }
}