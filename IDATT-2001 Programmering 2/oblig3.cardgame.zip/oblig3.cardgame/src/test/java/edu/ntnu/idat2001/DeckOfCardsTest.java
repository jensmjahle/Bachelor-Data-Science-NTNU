package edu.ntnu.idat2001;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DeckOfCardsTest {

  @Test
  void dealHand() {
    DeckOfCards deck = new DeckOfCards();
    HandOfCards hand = new HandOfCards(deck.dealHand(5));
    assertEquals(5, hand.getHandOfCards().size());
  }

  @Test
  void throwsExceptionWhenDealingMoreThan52Cards() {
    DeckOfCards deck = new DeckOfCards();
    assertThrows(IllegalArgumentException.class, () -> deck.dealHand(53));
  }

  @Test
  void throwsExceptionWhenDealingLessThan1Card() {
    DeckOfCards deck = new DeckOfCards();
    assertThrows(IllegalArgumentException.class, () -> deck.dealHand(0));
  }
}