package edu.ntnu.idat2001;

/**
 * This is the main class of the application.
 */
public class App {

  /**
   * The main method is only needed for the IDE with limited
   * JavaFX support. Not needed for running from the command line.
   */
  public static void main(String[] args) {
    GUI.main(args);
  }
}
