package edu.ntnu.idat2001;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.Collection;

/**
 * JavaFX App
 */
public class GUI extends Application {
    private HandOfCards handOfCards;
    private final DeckOfCards deckOfCards = new DeckOfCards();
    private Label flushLabel;
    private Label sumOfAllCardslabel;
    private Label cardsOfHeartlabel;
    private Label spadeQueenExistsLabel;
    ListView<PlayingCard> playingCardListView = new ListView<>();
    ObservableList<PlayingCard> cards = FXCollections.observableArrayList();

    /**
     * The main method is only needed for the IDE with limited
     * JavaFX support. Not needed for running from the command line.
     */
    public static void main(String[] args) {
       launch(args);
    }

    /**
     * Starts the application
     * @param Primarystage The stage
     */
    @Override
    public void start(Stage Primarystage) {

        playingCardListView.setItems(cards);

        Primarystage.setTitle("Card game");

        handOfCards = new HandOfCards(deckOfCards.dealHand(5));

        flushLabel = new Label("Flush:");
        sumOfAllCardslabel = new Label("Sum of cards:");
        cardsOfHeartlabel = new Label("Cards of heart:");
        spadeQueenExistsLabel = new Label("Spade queen:");

        VBox infoBox = new VBox(10, flushLabel, sumOfAllCardslabel, cardsOfHeartlabel, spadeQueenExistsLabel);
        infoBox.setPadding(new Insets(20));

        Button DealCardsButton = new Button("Deal cards");
        DealCardsButton.setId("DealCardsButton");

        playingCardListView.setPadding(new Insets(40));

        BorderPane root = new BorderPane();

        VBox buttonBox = new VBox();
        buttonBox.setPadding(new Insets(20));
        buttonBox.getChildren().add(DealCardsButton);

        root.setRight(buttonBox);
        root.setCenter(playingCardListView);
        root.setBottom(infoBox);


        Scene scene = new Scene(root, 700, 500);
        Primarystage.setScene(scene);
        Primarystage.show();


        EventHandler<ActionEvent> dealCards = new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                fillPlayingCardListView();
                playingCardListView.setItems(cards);
                updateFlushLabel();
                updateSumOfAllCardsLabel();
                updateCardsOfHeartLabel();
                updateSpadeQueenExistsLabel();
            }
        };
        DealCardsButton.setOnAction(dealCards);
    }

    /**
     * Fills playingCardListView with new cards
     */
    private void fillPlayingCardListView() {
        Collection<PlayingCard> NewCards = deckOfCards.dealHand(5);
        cards.clear();
        cards.addAll(NewCards);
        handOfCards = new HandOfCards(NewCards);
    }

    /**
     * Updates flushLabel
     */
    private void updateFlushLabel() {
        boolean flush = handOfCards.flush();
        if (flush) {
            flushLabel.setText("Flush: YES");
        } else {
            flushLabel.setText("Flush: NO");
        }

    }

    /**
     * Updates sumOfAllCardslabel
     */
    private void updateSumOfAllCardsLabel() {
        int sumOfAllCards = handOfCards.getSumOfAllCards();
        sumOfAllCardslabel.setText("Sum of cards: " + sumOfAllCards);
    }

    /**
     * Updates cardsOfHeartlabel
     */
    private void updateCardsOfHeartLabel() {
        String cardsOfHeart = handOfCards.getCardsOfHeart().toString();
        cardsOfHeartlabel.setText("Cards of heart: " + cardsOfHeart);
    }

    /**
     * Updates spadeQueenExistsLabel
     */
    private void updateSpadeQueenExistsLabel() {
        boolean spadeQueenExists = handOfCards.spadeQueenExist();
        if (spadeQueenExists) {
            spadeQueenExistsLabel.setText("Spade queen: YES");
        } else {
            spadeQueenExistsLabel.setText("Spade queen: NO");
        }
    }
}