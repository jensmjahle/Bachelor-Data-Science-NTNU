package edu.ntnu.idat2001;


import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

/**
 * This is the main class of the application.
 */
public class DeckOfCards {
    private final List<PlayingCard> deckOfCards;

    /**
     * Creates a new instance of App
     */
    public DeckOfCards () {
        char[] suit = {'S', 'H', 'D', 'C'};
        this.deckOfCards = new ArrayList<>();
        for (char c : suit) {
            int[] face = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13};
            for (int j : face) {
                deckOfCards.add(new PlayingCard(c, j));
            }
        }
    }

    /**
     * Returns a collection of n cards from the deck of cards.
     * @param n the number of cards to deal
     * @return a collection of n cards from the deck of cards
     */
    public Collection<PlayingCard> dealHand(int n) {
        if (n < 1 || n > 52) {
            throw new IllegalArgumentException("n must be a number between 1 and 52.");
        }
        List<PlayingCard> handOfCards = new ArrayList<>();
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            handOfCards.add(deckOfCards.get(random.nextInt(deckOfCards.size())));
        }
        return handOfCards;

    }

    @Override
    public String toString() {
        return "Deck Of Cards " + deckOfCards ;
    }
}
