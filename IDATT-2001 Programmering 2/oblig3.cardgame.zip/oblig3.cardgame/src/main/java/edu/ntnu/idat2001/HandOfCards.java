package edu.ntnu.idat2001;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Represents a hand of cards.
 */
public class HandOfCards {
    private final Collection<PlayingCard> cards;

    /**
     * Creates a new instance of HandOfCards
     * @param cards the cards in the hand
     */
    public HandOfCards(Collection<PlayingCard> cards) {
        this.cards = cards;
    }

    /**
     * Returns the cards in the hand.
     * @return the cards in the hand
     */
    public Collection<PlayingCard> getHandOfCards() {
        return cards;
    }

    /**
     * Returns true if the hand is a flush, false otherwise.
     * @return true if the hand is a flush, false otherwise
     */
    public boolean flush() {
        boolean flush = false;
        char suit = (char) cards.iterator().next().getSuit();
        List<PlayingCard> listWithSameSuitAsFirstCard =
            cards.stream().filter(PlayingCard -> PlayingCard.getSuit() == suit).toList();
        if (listWithSameSuitAsFirstCard.size() == 5) {
            flush = true;
        }
        return flush;
    }

    /**
     * Returns sum of all cards in the hand.
     * @return sum of all cards in the hand
     */
    public int getSumOfAllCards() {
        return cards.stream()
            .mapToInt(PlayingCard::getFace)
            .sum();
    }

    /**
     * Returns the cards in the hand that are of the heart suit.
     * @return the cards in the hand that are of the heart suit
     */
    public Collection<PlayingCard> getCardsOfHeart() {
        return cards.stream()
            .filter(PlayingCard -> PlayingCard.getSuit() == 'H').collect(Collectors.toList());
    }

    /**
     * Returns true if the hand contains a queen of spades, false otherwise.
     * @return true if the hand contains a queen of spades, false otherwise
     */
    public boolean spadeQueenExist() {
        boolean spadeQueen = false;
        List<PlayingCard> listOfCards = cards.stream().filter(PlayingCard -> PlayingCard.toString().equals(" S12")).toList();
        if (listOfCards.size() > 0) {
            spadeQueen = true;
        }
        return spadeQueen;
    }

    @Override
    public String toString() {
        return "Hand Of Cards " + cards;
    }
}
